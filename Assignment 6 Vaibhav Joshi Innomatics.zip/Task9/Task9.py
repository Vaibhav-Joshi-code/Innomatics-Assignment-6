import numpy as np
m=map(int,input().split())
n=[]
for i in range(m[0]):
    n.append(map(int,input().split()))

print(np.prod(np.sum(n,axis=0)))
