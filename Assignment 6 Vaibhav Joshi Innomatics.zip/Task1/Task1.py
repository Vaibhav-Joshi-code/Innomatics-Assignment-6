import numpy

def arrays(arr):
    # comlete this function
    # use numpy.array
    return(numpy.array(arr[::-1],float))
arr = input().strip().split(' ')
