import numpy
p,q = list(int(x) for x in input().split())
print(numpy.eye(p,q))
