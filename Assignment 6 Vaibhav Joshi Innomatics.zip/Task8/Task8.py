import numpy as np
a = list(map(float,input().split()))
a = np.array(a)
print(np.floor(a))
print(np.ceil(a))
print(np.rint(a))
