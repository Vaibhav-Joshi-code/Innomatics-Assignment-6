import numpy
l=map(int,input().split())
a=[]
b=[]
for i in range(l[0]):
    a.append(map(int,input().split()))
for i in range(l[0]):
    b.append(map(int,input().split()))
a=numpy.array(a)
b=numpy.array(b)
print(numpy.add(a,b))
print(numpy.subtract(a,b))
print(numpy.multiply(a,b))
print(numpy.divide(a,b))
print(numpy.mod(a,b))
print(a**b)
