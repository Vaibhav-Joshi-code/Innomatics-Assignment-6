import numpy as np
m = list(map(int, input().split()))
print(np.zeros(m,dtype=np.int64))
print(np.ones(m,dtype=np.int64))
